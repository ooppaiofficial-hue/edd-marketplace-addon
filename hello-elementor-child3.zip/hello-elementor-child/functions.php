<?php
/**
 * Hello Elementor Child Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * =====================================
 * Enqueue Styles & Scripts
 * =====================================
 */
add_action('wp_enqueue_scripts', 'gamebani_enqueue_assets');
function gamebani_enqueue_assets() {

	/**
	 * ========= Styles =========
	 */

	wp_enqueue_style(
		'child-style',
		get_stylesheet_uri(),
		[],
		wp_get_theme()->get('Version')
	);

	wp_enqueue_style(
		'gaming-header',
		get_stylesheet_directory_uri() . '/assets/css/header.css',
		['child-style'],
		'1.0'
	);

	wp_enqueue_style(
		'gaming-footer',
		get_stylesheet_directory_uri() . '/assets/css/footer.css',
		['child-style'],
		'1.0'
	);

	// Dashicons frontend
	wp_enqueue_style('dashicons');


	/**
	 * ========= Scripts =========
	 */

	wp_enqueue_script(
		'gaming-header',
		get_stylesheet_directory_uri() . '/assets/js/header.js',
		[],
		'1.1',
		true
	);

	// فقط اگر کاربر لاگین است داده logout ارسال شود
	if ( is_user_logged_in() ) {
		wp_localize_script(
			'gaming-header',
			'GAMEBANI_LOGOUT',
			[
				'ajax_url' => admin_url('admin-ajax.php'),
				'nonce'    => wp_create_nonce('gamebani_logout_nonce'),
				'redirect' => home_url('/')
			]
		);
	}
}


/**
 * =====================================
 * Secure AJAX Logout (VPN Safe)
 * =====================================
 */

add_action('wp_ajax_gamebani_logout', 'gamebani_ajax_logout');

function gamebani_ajax_logout() {

	check_ajax_referer('gamebani_logout_nonce', 'nonce');

	if ( is_user_logged_in() ) {

		// Logout استاندارد وردپرس
		wp_logout();

		// پاکسازی کامل session
		wp_destroy_current_session();
		wp_clear_auth_cookie();
	}

	wp_send_json_success([
		'redirect' => home_url('/')
	]);
}
