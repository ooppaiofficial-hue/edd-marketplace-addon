document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.gaming-header');
  const mobileToggle = document.querySelector('.gaming-mobile-toggle');

  if (header && mobileToggle) {
    mobileToggle.addEventListener('click', () => {
      const isOpen = header.classList.toggle('menu-open');
      mobileToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      const navPanel = document.getElementById('gaming-nav-panel');
      if (navPanel) navPanel.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
    });
  }

  document.querySelectorAll('.dropdown').forEach((drop) => {
    const trigger = drop.querySelector('.dropdown-text, .btn-sell, .sell-account-btn');
    if (!trigger) return;

    trigger.addEventListener('click', (e) => {
      if (window.innerWidth > 992) return;
      e.preventDefault();
      drop.classList.toggle('open');
    });
  });

  document.addEventListener('click', (e) => {
    document.querySelectorAll('.dropdown').forEach((drop) => {
      if (!drop.contains(e.target) && window.innerWidth <= 992) {
        drop.classList.remove('open');
      }
    });
  });

  const sellBtn = document.querySelector('.sell-account-btn');
  if (sellBtn) {
    sellBtn.addEventListener('click', (e) => {
      if (!document.body.classList.contains('logged-in')) {
        e.preventDefault();
        showLoginWarning();
      }
    });
  }

  const logoutBtn = document.getElementById('gamebani-logout-btn');
  if (logoutBtn && typeof GAMEBANI_LOGOUT !== 'undefined') {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      fetch(GAMEBANI_LOGOUT.ajax_url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'gamebani_logout',
          nonce: GAMEBANI_LOGOUT.nonce
        })
      })
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.data.redirect) {
          window.location.href = data.data.redirect;
        } else {
          location.reload();
        }
      })
      .catch(() => location.reload());
    });
  }
});

function showLoginWarning() {
  if (document.querySelector('.login-warning')) return;

  const warning = document.createElement('div');
  warning.className = 'login-warning';
  warning.innerHTML = 'لطفا ابتدا با دکمه <span class="steam-highlight">ورود/ثبت نام</span> وارد سایت شوید.';
  document.body.appendChild(warning);

  setTimeout(() => warning.classList.add('active'), 50);
  setTimeout(() => {
    warning.classList.remove('active');
    setTimeout(() => warning.remove(), 350);
  }, 3500);
}
