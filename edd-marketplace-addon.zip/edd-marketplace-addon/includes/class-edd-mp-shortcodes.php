<?php
/**
 * Frontend shortcodes and assets.
 *
 * @package EDD_Marketplace_Addon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EDD_MP_Shortcodes {
	const OPTION_CHECKOUT_PAGE_ID = 'edd_mp_checkout_page_id';
	const SHORTCODE_CART          = 'edd_mp_cart';
	const SHORTCODE_CHECKOUT      = 'edd_mp_checkout';
	const AJAX_NONCE_ACTION       = 'edd_mp_checkout_actions';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_shortcode( self::SHORTCODE_CART, array( $this, 'render_cart_shortcode' ) );
		add_shortcode( self::SHORTCODE_CHECKOUT, array( $this, 'render_checkout_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_ajax_edd_mp_remove_cart_item', array( $this, 'ajax_remove_cart_item' ) );
		add_action( 'wp_ajax_nopriv_edd_mp_remove_cart_item', array( $this, 'ajax_remove_cart_item' ) );

		add_filter( 'edd_purchase_form_user_info_fields', array( $this, 'remove_checkout_user_info_fields' ) );
		add_filter( 'edd_purchase_form_required_fields', array( $this, 'remove_checkout_required_fields' ) );
	}

	/**
	 * Ensure plugin checkout page exists.
	 *
	 * @return void
	 */
	public function ensure_checkout_page_exists() {
		$page_id = (int) get_option( self::OPTION_CHECKOUT_PAGE_ID, 0 );
		if ( $page_id > 0 && 'trash' !== get_post_status( $page_id ) ) {
			return;
		}

		$existing = get_page_by_path( 'edd-marketplace-checkout', OBJECT, 'page' );
		if ( $existing instanceof WP_Post ) {
			update_option( self::OPTION_CHECKOUT_PAGE_ID, (int) $existing->ID );
			return;
		}

		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => __( 'Marketplace Checkout', 'edd-marketplace-addon' ),
				'post_name'    => 'edd-marketplace-checkout',
				'post_content' => '[' . self::SHORTCODE_CHECKOUT . ']',
			),
			true
		);

		if ( ! is_wp_error( $page_id ) && $page_id > 0 ) {
			update_option( self::OPTION_CHECKOUT_PAGE_ID, (int) $page_id );
		}
	}

	/**
	 * Get checkout page URL.
	 *
	 * @return string
	 */
	private function get_checkout_page_url() {
		$page_id = (int) get_option( self::OPTION_CHECKOUT_PAGE_ID, 0 );
		if ( $page_id > 0 ) {
			$url = get_permalink( $page_id );
			if ( ! empty( $url ) ) {
				return $url;
			}
		}

		return function_exists( 'edd_get_checkout_uri' ) ? edd_get_checkout_uri() : home_url( '/' );
	}

	/**
	 * Register frontend assets.
	 *
	 * @return void
	 */
	public function register_assets() {
		wp_register_style(
			'edd-mp-cart-style',
			EDD_MP_ADDON_URL . 'assets/css/edd-mp-cart.css',
			array(),
			EDD_MP_ADDON_VERSION
		);

		wp_register_script(
			'edd-mp-cart-script',
			EDD_MP_ADDON_URL . 'assets/js/edd-mp-cart.js',
			array(),
			EDD_MP_ADDON_VERSION,
			true
		);

		wp_localize_script(
			'edd-mp-cart-script',
			'eddMpCheckout',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::AJAX_NONCE_ACTION ),
			)
		);
	}

	/**
	 * Remove Personal Info fields from EDD checkout.
	 *
	 * @param array<string,mixed> $fields Checkout fields.
	 * @return array<string,mixed>
	 */
	public function remove_checkout_user_info_fields( $fields ) {
		if ( ! $this->is_marketplace_checkout_page() ) {
			return $fields;
		}

		return array();
	}

	/**
	 * Remove required Personal Info fields.
	 *
	 * @param array<string,mixed> $required Required fields.
	 * @return array<string,mixed>
	 */
	public function remove_checkout_required_fields( $required ) {
		if ( ! $this->is_marketplace_checkout_page() ) {
			return $required;
		}

		return array();
	}

	/**
	 * Determine whether we are on marketplace checkout page.
	 *
	 * @return bool
	 */
	private function is_marketplace_checkout_page() {
		if ( ! function_exists( 'is_page' ) ) {
			return false;
		}

		$page_id = (int) get_option( self::OPTION_CHECKOUT_PAGE_ID, 0 );
		if ( $page_id <= 0 ) {
			return false;
		}

		return is_page( $page_id );
	}

	/**
	 * Render cart shortcode.
	 *
	 * @param array<string,mixed> $atts Attributes.
	 * @return string
	 */
	public function render_cart_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'show_total' => 'yes',
			),
			$atts,
			self::SHORTCODE_CART
		);

		wp_enqueue_style( 'edd-mp-cart-style' );
		wp_enqueue_script( 'edd-mp-cart-script' );

		$cart_items = edd_get_cart_contents();
		if ( ! is_array( $cart_items ) ) {
			$cart_items = array();
		}

		$cart_count = function_exists( 'edd_get_cart_quantity' ) ? (int) edd_get_cart_quantity() : count( $cart_items );
		$cart_url   = $this->get_checkout_page_url();
		$popup_id   = function_exists( 'wp_unique_id' ) ? wp_unique_id( 'edd-mp-cart-popup-' ) : 'edd-mp-cart-popup';

		ob_start();
		?>
		<div class="edd-mp-cart-shortcode" data-edd-mp-cart>
			<button type="button" class="edd-mp-cart-toggle" aria-expanded="false" aria-haspopup="dialog" aria-controls="<?php echo esc_attr( $popup_id ); ?>">
				<span class="edd-mp-cart-toggle-label"><?php echo esc_html__( 'Cart', 'edd-marketplace-addon' ); ?></span>
				<span class="edd-mp-cart-badge" aria-label="<?php echo esc_attr( sprintf( __( '%d items in cart', 'edd-marketplace-addon' ), $cart_count ) ); ?>"><?php echo esc_html( (string) $cart_count ); ?></span>
			</button>

			<div id="<?php echo esc_attr( $popup_id ); ?>" class="edd-mp-cart-popup" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__( 'Cart details', 'edd-marketplace-addon' ); ?>" hidden>
				<div class="edd-mp-cart-popup-content">
					<button type="button" class="edd-mp-cart-popup-close" aria-label="<?php echo esc_attr__( 'Close cart popup', 'edd-marketplace-addon' ); ?>">&times;</button>

					<?php if ( empty( $cart_items ) ) : ?>
						<p class="edd-mp-empty-cart"><?php echo esc_html__( 'Your cart is empty.', 'edd-marketplace-addon' ); ?></p>
					<?php else : ?>
						<ul class="edd-mp-cart-list">
							<?php foreach ( $cart_items as $item ) : ?>
								<?php
								$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
								if ( $download_id <= 0 ) {
									continue;
								}

								$options    = isset( $item['options'] ) && is_array( $item['options'] ) ? $item['options'] : array();
								$item_price = (float) edd_get_cart_item_price( $download_id, $options, false );
								$title      = get_the_title( $download_id );
								?>
								<li class="edd-mp-cart-item">
									<span class="edd-mp-cart-item-title"><?php echo esc_html( $title ); ?></span>
									<?php if ( 'yes' === strtolower( (string) $atts['show_total'] ) ) : ?>
										<span class="edd-mp-cart-item-price"><?php echo esc_html( edd_currency_filter( edd_format_amount( $item_price ) ) ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>

					<a class="edd-mp-cart-link" href="<?php echo esc_url( $cart_url ); ?>"><?php echo esc_html__( 'View Cart / Checkout', 'edd-marketplace-addon' ); ?></a>
				</div>
			</div>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Render dedicated checkout page content.
	 *
	 * @return string
	 */
	public function render_checkout_shortcode() {
		wp_enqueue_style( 'edd-mp-cart-style' );
		wp_enqueue_script( 'edd-mp-cart-script' );

		$cart_items = edd_get_cart_contents();
		if ( ! is_array( $cart_items ) ) {
			$cart_items = array();
		}

		ob_start();
		?>
		<div class="edd-mp-checkout-page" data-edd-mp-checkout>
			<h2><?php echo esc_html__( 'Your Order', 'edd-marketplace-addon' ); ?></h2>

			<div class="edd-mp-checkout-items" data-edd-mp-checkout-items>
				<?php echo $this->render_checkout_items( $cart_items ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>

			<?php if ( ! empty( $cart_items ) ) : ?>
				<div class="edd-mp-checkout-native">
					<?php echo do_shortcode( '[download_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Render checkout cart items list.
	 *
	 * @param array<int,mixed> $cart_items Cart items.
	 * @return string
	 */
	private function render_checkout_items( $cart_items ) {
		if ( empty( $cart_items ) ) {
			return '<p class="edd-mp-empty-cart">' . esc_html__( 'Your cart is empty.', 'edd-marketplace-addon' ) . '</p>';
		}

		ob_start();
		?>
		<div class="edd-mp-checkout-list">
			<?php foreach ( $cart_items as $key => $item ) : ?>
				<?php
				$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
				if ( $download_id <= 0 ) {
					continue;
				}

				$options    = isset( $item['options'] ) && is_array( $item['options'] ) ? $item['options'] : array();
				$item_price = (float) edd_get_cart_item_price( $download_id, $options, false );
				$title      = get_the_title( $download_id );
				$thumb      = get_the_post_thumbnail_url( $download_id, 'thumbnail' );
				?>
				<div class="edd-mp-checkout-item" data-cart-key="<?php echo esc_attr( (string) $key ); ?>">
					<div class="edd-mp-checkout-item-media">
						<?php if ( ! empty( $thumb ) ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" />
						<?php else : ?>
							<div class="edd-mp-checkout-item-no-image"></div>
						<?php endif; ?>
					</div>

					<div class="edd-mp-checkout-item-content">
						<h3 class="edd-mp-checkout-item-title"><?php echo esc_html( $title ); ?></h3>
						<button type="button" class="edd-mp-remove-item" data-cart-key="<?php echo esc_attr( (string) $key ); ?>">
							<?php echo esc_html__( 'Remove from cart', 'edd-marketplace-addon' ); ?>
						</button>
					</div>

					<div class="edd-mp-checkout-item-price"><?php echo esc_html( edd_currency_filter( edd_format_amount( $item_price ) ) ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>

		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Ajax: remove an item from the cart without page refresh.
	 *
	 * @return void
	 */
	public function ajax_remove_cart_item() {
		check_ajax_referer( self::AJAX_NONCE_ACTION, 'nonce' );

		$cart_key = isset( $_POST['cart_key'] ) ? absint( $_POST['cart_key'] ) : -1;
		if ( $cart_key < 0 ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Invalid cart item.', 'edd-marketplace-addon' ),
				)
			);
		}

		if ( function_exists( 'edd_remove_from_cart' ) ) {
			edd_remove_from_cart( $cart_key );
		}

		$cart_items = edd_get_cart_contents();
		if ( ! is_array( $cart_items ) ) {
			$cart_items = array();
		}

		wp_send_json_success(
			array(
				'itemsHtml'  => $this->render_checkout_items( $cart_items ),
				'cartCount'  => function_exists( 'edd_get_cart_quantity' ) ? (int) edd_get_cart_quantity() : count( $cart_items ),
				'cartIsEmpty' => empty( $cart_items ),
			)
		);
	}
}
