<?php
/**
 * Core plugin class.
 *
 * @package EDD_Marketplace_Addon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EDD_Marketplace_Addon {

	const META_COMMISSION_PERCENT    = '_edd_mp_commission_percent';
	const PAYMENT_META_COMMISSIONS   = '_edd_mp_commissions';
	const NONCE_ACTION_DOWNLOAD      = 'edd_mp_save_download_commission';
	const NONCE_NAME_DOWNLOAD        = 'edd_mp_download_commission_nonce';
	const OPTION_CHECKOUT_PAGE_ID    = 'edd_mp_checkout_page_id';
	const SHORTCODE_CART             = 'edd_mp_cart';
	const SHORTCODE_CHECKOUT         = 'edd_mp_checkout';

	/**
	 * Singleton instance.
	 *
	 * @var EDD_Marketplace_Addon|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @return EDD_Marketplace_Addon
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Activation callback.
	 */
	public static function activate() {
		$instance = self::instance();
		$instance->ensure_checkout_page_exists();
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'plugins_loaded', array( $this, 'bootstrap' ), 20 );
	}

	/**
	 * Load plugin textdomain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'edd-marketplace-addon', false, dirname( plugin_basename( EDD_MP_ADDON_FILE ) ) . '/languages' );
	}

	/**
	 * Register plugin hooks.
	 */
	public function bootstrap() {
		if ( ! class_exists( 'Easy_Digital_Downloads' ) && ! defined( 'EDD_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'render_missing_edd_notice' ) );
			return;
		}

		$this->ensure_checkout_page_exists();

		add_filter( 'edd_currencies', array( $this, 'register_iran_toman_currency' ) );
		add_filter( 'edd_currency_symbol', array( $this, 'register_iran_toman_symbol' ), 10, 2 );
		add_filter( 'edd_get_payment_currency', array( $this, 'force_payment_currency' ) );
		add_filter( 'edd_currency_decimal_count', array( $this, 'adjust_decimal_count_for_irt' ), 20, 2 );

		add_filter( 'edd_settings_general', array( $this, 'register_edd_general_settings' ) );
		add_filter( 'edd_settings_extensions', array( $this, 'register_edd_extensions_settings' ) );

		add_shortcode( self::SHORTCODE_CART, array( $this, 'render_cart_shortcode' ) );
		add_shortcode( self::SHORTCODE_CHECKOUT, array( $this, 'render_checkout_shortcode' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );

		add_action( 'add_meta_boxes', array( $this, 'register_download_meta_box' ) );
		add_action( 'save_post_download', array( $this, 'save_download_commission_meta' ) );
		add_action( 'edd_complete_purchase', array( $this, 'store_payment_commissions' ), 20, 1 );
	}

	/**
	 * Ensure plugin checkout page exists.
	 */
	private function ensure_checkout_page_exists() {
		$page_id = (int) get_option( self::OPTION_CHECKOUT_PAGE_ID, 0 );
		if ( $page_id > 0 && 'trash' !== get_post_status( $page_id ) ) {
			return;
		}

		$existing = get_page_by_path( 'edd-marketplace-checkout', OBJECT, 'page' );
		if ( $existing instanceof WP_Post ) {
			update_option( self::OPTION_CHECKOUT_PAGE_ID, (int) $existing->ID );
			return;
		}

		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => __( 'Marketplace Checkout', 'edd-marketplace-addon' ),
				'post_name'    => 'edd-marketplace-checkout',
				'post_content' => '[' . self::SHORTCODE_CHECKOUT . ']',
			),
			true
		);

		if ( ! is_wp_error( $page_id ) && $page_id > 0 ) {
			update_option( self::OPTION_CHECKOUT_PAGE_ID, (int) $page_id );
		}
	}

	/**
	 * Get checkout page URL.
	 *
	 * @return string
	 */
	private function get_checkout_page_url() {
		$page_id = (int) get_option( self::OPTION_CHECKOUT_PAGE_ID, 0 );
		if ( $page_id > 0 ) {
			$url = get_permalink( $page_id );
			if ( ! empty( $url ) ) {
				return $url;
			}
		}

		return function_exists( 'edd_get_checkout_uri' ) ? edd_get_checkout_uri() : home_url( '/' );
	}

	/**
	 * Register frontend assets.
	 */
	public function register_assets() {
		wp_register_style(
			'edd-mp-cart-style',
			EDD_MP_ADDON_URL . 'assets/css/edd-mp-cart.css',
			array(),
			EDD_MP_ADDON_VERSION
		);

		wp_register_script(
			'edd-mp-cart-script',
			EDD_MP_ADDON_URL . 'assets/js/edd-mp-cart.js',
			array(),
			EDD_MP_ADDON_VERSION,
			true
		);
	}

	/**
	 * Render notice when EDD is not active.
	 */
	public function render_missing_edd_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-error"><p>';
		echo esc_html__( 'EDD Marketplace Addon requires Easy Digital Downloads to be installed and active.', 'edd-marketplace-addon' );
		echo '</p></div>';
	}

	/**
	 * Add Iran Toman currency.
	 *
	 * @param array<string,string> $currencies Currency list.
	 * @return array<string,string>
	 */
	public function register_iran_toman_currency( $currencies ) {
		$currencies['IRT'] = __( 'Iran Toman (IRT)', 'edd-marketplace-addon' );
		return $currencies;
	}

	/**
	 * Set symbol for Iran Toman.
	 *
	 * @param string $symbol Symbol.
	 * @param string $currency Currency code.
	 * @return string
	 */
	public function register_iran_toman_symbol( $symbol, $currency ) {
		if ( 'IRT' === strtoupper( (string) $currency ) ) {
			return 'تومان';
		}

		return $symbol;
	}

	/**
	 * Add currency settings to EDD general tab.
	 *
	 * @param array<int,mixed> $settings Settings.
	 * @return array<int,mixed>
	 */
	public function register_edd_general_settings( $settings ) {
		$settings[] = array(
			'id'   => 'edd_mp_currency_header',
			'name' => '<strong>' . esc_html__( 'Marketplace Addon', 'edd-marketplace-addon' ) . '</strong>',
			'type' => 'header',
		);

		$settings[] = array(
			'id'   => 'edd_mp_force_irt_currency',
			'name' => esc_html__( 'Force Iran Toman for payments', 'edd-marketplace-addon' ),
			'desc' => esc_html__( 'When enabled, all payment currency values are stored as IRT (Iran Toman).', 'edd-marketplace-addon' ),
			'type' => 'checkbox',
		);

		return $settings;
	}

	/**
	 * Add commission settings to EDD extensions tab.
	 *
	 * @param array<int,mixed> $settings Settings.
	 * @return array<int,mixed>
	 */
	public function register_edd_extensions_settings( $settings ) {
		$settings[] = array(
			'id'   => 'edd_mp_commission_header',
			'name' => '<strong>' . esc_html__( 'Marketplace Commission', 'edd-marketplace-addon' ) . '</strong>',
			'type' => 'header',
		);

		$settings[] = array(
			'id'   => 'edd_mp_global_commission_percent',
			'name' => esc_html__( 'Global commission (%)', 'edd-marketplace-addon' ),
			'desc' => esc_html__( 'Default commission percentage used when product-specific commission is empty. Range: 0 to 100.', 'edd-marketplace-addon' ),
			'type' => 'number',
			'size' => 'small',
			'std'  => $this->get_default_global_commission(),
			'min'  => '0',
			'max'  => '100',
			'step' => '0.01',
		);

		return $settings;
	}

	/**
	 * Force payment currency.
	 *
	 * @param string $currency Current currency.
	 * @return string
	 */
	public function force_payment_currency( $currency ) {
		$force = edd_get_option( 'edd_mp_force_irt_currency', false );
		if ( $force ) {
			return 'IRT';
		}

		return $currency;
	}

	/**
	 * Force decimal count to 0 for IRT.
	 *
	 * @param int    $decimals Decimal count.
	 * @param string $currency Currency code.
	 * @return int
	 */
	public function adjust_decimal_count_for_irt( $decimals, $currency ) {
		if ( 'IRT' === strtoupper( (string) $currency ) || $this->is_irt_currency_active() ) {
			return 0;
		}

		return (int) $decimals;
	}

	/**
	 * Determine whether IRT is active.
	 *
	 * @return bool
	 */
	private function is_irt_currency_active() {
		$forced = edd_get_option( 'edd_mp_force_irt_currency', false );
		if ( $forced ) {
			return true;
		}

		$currency = edd_get_currency();
		return 'IRT' === strtoupper( (string) $currency );
	}

	/**
	 * Render cart shortcode.
	 *
	 * @param array<string,mixed> $atts Attributes.
	 * @return string
	 */
	public function render_cart_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'show_total' => 'yes',
			),
			$atts,
			self::SHORTCODE_CART
		);

		wp_enqueue_style( 'edd-mp-cart-style' );
		wp_enqueue_script( 'edd-mp-cart-script' );

		$cart_items = edd_get_cart_contents();
		if ( ! is_array( $cart_items ) ) {
			$cart_items = array();
		}

		$cart_count = function_exists( 'edd_get_cart_quantity' ) ? (int) edd_get_cart_quantity() : count( $cart_items );
		$cart_url   = $this->get_checkout_page_url();

		ob_start();
		?>
		<div class="edd-mp-cart-shortcode" data-edd-mp-cart>
			<button type="button" class="edd-mp-cart-toggle" aria-expanded="false">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d is cart items count. */
						__( 'Cart (%d)', 'edd-marketplace-addon' ),
						$cart_count
					)
				);
				?>
			</button>

			<div class="edd-mp-cart-content" hidden>
				<?php if ( empty( $cart_items ) ) : ?>
					<p class="edd-mp-empty-cart"><?php echo esc_html__( 'Your cart is empty.', 'edd-marketplace-addon' ); ?></p>
				<?php else : ?>
					<ul class="edd-mp-cart-list">
						<?php foreach ( $cart_items as $item ) : ?>
							<?php
							$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
							if ( $download_id <= 0 ) {
								continue;
							}

							$options    = isset( $item['options'] ) && is_array( $item['options'] ) ? $item['options'] : array();
							$item_price = (float) edd_get_cart_item_price( $download_id, $options, false );
							$title      = get_the_title( $download_id );
							?>
							<li class="edd-mp-cart-item">
								<span class="edd-mp-cart-item-title"><?php echo esc_html( $title ); ?></span>
								<?php if ( 'yes' === strtolower( (string) $atts['show_total'] ) ) : ?>
									<span class="edd-mp-cart-item-price"><?php echo esc_html( edd_currency_filter( edd_format_amount( $item_price ) ) ); ?></span>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<a class="edd-mp-cart-link" href="<?php echo esc_url( $cart_url ); ?>"><?php echo esc_html__( 'View Cart / Checkout', 'edd-marketplace-addon' ); ?></a>
			</div>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Render dedicated checkout page content.
	 *
	 * @return string
	 */
	public function render_checkout_shortcode() {
		wp_enqueue_style( 'edd-mp-cart-style' );

		$cart_items = edd_get_cart_contents();
		if ( ! is_array( $cart_items ) ) {
			$cart_items = array();
		}

		ob_start();
		?>
		<div class="edd-mp-checkout-page">
			<h2><?php echo esc_html__( 'Your Order', 'edd-marketplace-addon' ); ?></h2>

			<?php if ( empty( $cart_items ) ) : ?>
				<p class="edd-mp-empty-cart"><?php echo esc_html__( 'Your cart is empty.', 'edd-marketplace-addon' ); ?></p>
			<?php else : ?>
				<table class="edd-mp-checkout-table">
					<thead>
						<tr>
							<th><?php echo esc_html__( 'Product', 'edd-marketplace-addon' ); ?></th>
							<th><?php echo esc_html__( 'Price', 'edd-marketplace-addon' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $cart_items as $item ) : ?>
							<?php
							$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
							if ( $download_id <= 0 ) {
								continue;
							}

							$options    = isset( $item['options'] ) && is_array( $item['options'] ) ? $item['options'] : array();
							$item_price = (float) edd_get_cart_item_price( $download_id, $options, false );
							?>
							<tr>
								<td><?php echo esc_html( get_the_title( $download_id ) ); ?></td>
								<td><?php echo esc_html( edd_currency_filter( edd_format_amount( $item_price ) ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
					<tfoot>
						<tr>
							<th><?php echo esc_html__( 'Total', 'edd-marketplace-addon' ); ?></th>
							<th><?php echo esc_html( edd_currency_filter( edd_format_amount( edd_get_cart_total() ) ) ); ?></th>
						</tr>
					</tfoot>
				</table>

				<div class="edd-mp-checkout-native">
					<?php echo do_shortcode( '[download_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>
		</div>
		<?php

		return (string) ob_get_clean();
	}

	/**
	 * Register commission metabox on downloads.
	 */
	public function register_download_meta_box() {
		add_meta_box(
			'edd-mp-download-commission',
			esc_html__( 'Marketplace Commission', 'edd-marketplace-addon' ),
			array( $this, 'render_download_meta_box' ),
			'download',
			'side',
			'default'
		);
	}

	/**
	 * Render commission metabox.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function render_download_meta_box( $post ) {
		$value = get_post_meta( $post->ID, self::META_COMMISSION_PERCENT, true );
		wp_nonce_field( self::NONCE_ACTION_DOWNLOAD, self::NONCE_NAME_DOWNLOAD );
		?>
		<p>
			<label for="edd-mp-commission-percent"><?php echo esc_html__( 'Commission percent (%)', 'edd-marketplace-addon' ); ?></label>
			<input
				id="edd-mp-commission-percent"
				name="edd_mp_commission_percent"
				type="number"
				step="0.01"
				min="0"
				max="100"
				value="<?php echo esc_attr( '' !== $value ? (string) $value : '' ); ?>"
				style="width: 100%;"
			/>
		</p>
		<p class="description"><?php echo esc_html__( 'Leave empty to use the global commission from EDD settings.', 'edd-marketplace-addon' ); ?></p>
		<?php
	}

	/**
	 * Save commission metabox.
	 *
	 * @param int $post_id Post ID.
	 */
	public function save_download_commission_meta( $post_id ) {
		if ( ! isset( $_POST[ self::NONCE_NAME_DOWNLOAD ] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME_DOWNLOAD ] ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION_DOWNLOAD ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['edd_mp_commission_percent'] ) ) {
			delete_post_meta( $post_id, self::META_COMMISSION_PERCENT );
			return;
		}

		$raw_value = trim( (string) wp_unslash( $_POST['edd_mp_commission_percent'] ) );
		if ( '' === $raw_value ) {
			delete_post_meta( $post_id, self::META_COMMISSION_PERCENT );
			return;
		}

		$normalized = $this->normalize_percentage( (float) $raw_value );
		update_post_meta( $post_id, self::META_COMMISSION_PERCENT, $normalized );
	}

	/**
	 * Store commission data at purchase completion.
	 *
	 * @param int $payment_id Payment ID.
	 */
	public function store_payment_commissions( $payment_id ) {
		$payment_id = absint( $payment_id );
		if ( $payment_id <= 0 ) {
			return;
		}

		$existing = get_post_meta( $payment_id, self::PAYMENT_META_COMMISSIONS, true );
		if ( is_array( $existing ) && ! empty( $existing ) ) {
			return;
		}

		$cart_items = edd_get_payment_meta_cart_details( $payment_id, true );
		if ( empty( $cart_items ) || ! is_array( $cart_items ) ) {
			return;
		}

		$commissions = array();
		foreach ( $cart_items as $index => $item ) {
			$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
			if ( $download_id <= 0 ) {
				continue;
			}

			$line_total = isset( $item['price'] ) ? (float) $item['price'] : 0.0;
			if ( $line_total < 0 ) {
				$line_total = 0.0;
			}

			$commission_percent = $this->get_download_commission_percentage( $download_id );
			$commission_amount  = round( ( $line_total * $commission_percent ) / 100, edd_currency_decimal_filter() );
			$vendor_amount      = max( 0, $line_total - $commission_amount );
			$vendor_id          = (int) get_post_field( 'post_author', $download_id );

			$commissions[] = array(
				'index'              => absint( $index ),
				'download_id'        => $download_id,
				'line_total'         => $line_total,
				'commission_percent' => $commission_percent,
				'commission_amount'  => $commission_amount,
				'vendor_amount'      => $vendor_amount,
				'vendor_user_id'     => $vendor_id,
			);
		}

		if ( ! empty( $commissions ) ) {
			update_post_meta( $payment_id, self::PAYMENT_META_COMMISSIONS, $commissions );
		}
	}

	/**
	 * Get commission percentage for download.
	 *
	 * @param int $download_id Download ID.
	 * @return float
	 */
	private function get_download_commission_percentage( $download_id ) {
		$download_value = get_post_meta( $download_id, self::META_COMMISSION_PERCENT, true );
		if ( '' !== (string) $download_value ) {
			return $this->normalize_percentage( (float) $download_value );
		}

		return $this->get_global_commission_percentage();
	}

	/**
	 * Get global commission.
	 *
	 * @return float
	 */
	private function get_global_commission_percentage() {
		$value = edd_get_option( 'edd_mp_global_commission_percent', $this->get_default_global_commission() );
		return $this->normalize_percentage( (float) $value );
	}

	/**
	 * Default global commission.
	 *
	 * @return float
	 */
	private function get_default_global_commission() {
		return 10.0;
	}

	/**
	 * Normalize percentage value.
	 *
	 * @param float $value Value.
	 * @return float
	 */
	private function normalize_percentage( $value ) {
		$value = max( 0.0, min( 100.0, $value ) );
		return round( $value, 2 );
	}
}
