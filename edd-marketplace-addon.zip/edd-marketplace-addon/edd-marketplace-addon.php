<?php
/**
 * Plugin Name: EDD Marketplace Addon (Iran Toman + Commission)
 * Plugin URI:  https://example.com
 * Description: Adds Iran Toman currency support and configurable marketplace commissions to Easy Digital Downloads.
 * Version:     1.4.2
 * Author:      Marketplace EDD
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: edd-marketplace-addon
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'EDD_MP_ADDON_VERSION', '1.4.2' );
define( 'EDD_MP_ADDON_FILE', __FILE__ );
define( 'EDD_MP_ADDON_PATH', plugin_dir_path( __FILE__ ) );
define( 'EDD_MP_ADDON_URL', plugin_dir_url( __FILE__ ) );

require_once EDD_MP_ADDON_PATH . 'includes/class-edd-mp-currency.php';
require_once EDD_MP_ADDON_PATH . 'includes/class-edd-mp-commission.php';
require_once EDD_MP_ADDON_PATH . 'includes/class-edd-mp-shortcodes.php';
require_once EDD_MP_ADDON_PATH . 'includes/class-edd-marketplace-addon.php';

register_activation_hook( EDD_MP_ADDON_FILE, array( 'EDD_Marketplace_Addon', 'activate' ) );

EDD_Marketplace_Addon::instance();
