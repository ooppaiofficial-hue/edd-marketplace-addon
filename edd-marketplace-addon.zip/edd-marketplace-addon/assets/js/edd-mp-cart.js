(function () {
  'use strict';

  function closeAll(except) {
    document.querySelectorAll('[data-edd-mp-cart]').forEach(function (cart) {
      if (except && cart === except) {
        return;
      }

      var panel = cart.querySelector('.edd-mp-cart-content');
      var toggle = cart.querySelector('.edd-mp-cart-toggle');
      if (panel && toggle) {
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('.edd-mp-cart-toggle');

    if (toggle) {
      var cart = toggle.closest('[data-edd-mp-cart]');
      if (!cart) {
        return;
      }

      var panel = cart.querySelector('.edd-mp-cart-content');
      if (!panel) {
        return;
      }

      var willOpen = panel.hidden;
      closeAll(cart);
      panel.hidden = !willOpen;
      toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      return;
    }

    if (!event.target.closest('[data-edd-mp-cart]')) {
      closeAll(null);
    }
  });
})();
