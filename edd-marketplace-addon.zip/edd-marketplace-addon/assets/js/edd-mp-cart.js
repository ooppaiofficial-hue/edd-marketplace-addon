(function () {
  'use strict';

  function closeCart(cart) {
    if (!cart) {
      return;
    }

    var popup = cart.querySelector('.edd-mp-cart-popup');
    var toggle = cart.querySelector('.edd-mp-cart-toggle');

    if (popup) {
      popup.hidden = true;
      popup.style.removeProperty('--edd-mp-popup-top');
      popup.style.removeProperty('--edd-mp-popup-right');
    }

    if (toggle) {
      toggle.setAttribute('aria-expanded', 'false');
    }
  }

  function closeAll() {
    document.querySelectorAll('[data-edd-mp-cart]').forEach(function (cart) {
      closeCart(cart);
    });
  }

  function positionPopup(cart) {
    var popup = cart.querySelector('.edd-mp-cart-popup');
    var content = cart.querySelector('.edd-mp-cart-popup-content');
    var toggle = cart.querySelector('.edd-mp-cart-toggle');

    if (!popup || !content || !toggle) {
      return;
    }

    var buttonRect = toggle.getBoundingClientRect();
    var contentWidth = Math.min(content.offsetWidth || 360, window.innerWidth - 24);
    var right = Math.max(12, window.innerWidth - buttonRect.right);
    var maxRight = Math.max(12, window.innerWidth - contentWidth - 12);

    if (right > maxRight) {
      right = maxRight;
    }

    var top = buttonRect.bottom + 10;
    var maxTop = Math.max(12, window.innerHeight - 120);

    if (top > maxTop) {
      top = maxTop;
    }

    popup.style.setProperty('--edd-mp-popup-top', top + 'px');
    popup.style.setProperty('--edd-mp-popup-right', right + 'px');
  }

  function openCart(cart) {
    closeAll();

    var popup = cart.querySelector('.edd-mp-cart-popup');
    var toggle = cart.querySelector('.edd-mp-cart-toggle');

    if (!popup || !toggle) {
      return;
    }

    popup.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
    positionPopup(cart);
  }

  function bindCheckoutRemoveButtons() {
    document.querySelectorAll('.edd-mp-remove-item').forEach(function (button) {
      if (button.dataset.bound === '1') {
        return;
      }

      button.dataset.bound = '1';
      button.addEventListener('click', function () {
        var cartKey = button.getAttribute('data-cart-key');
        if (!cartKey || typeof eddMpCheckout === 'undefined') {
          return;
        }

        button.disabled = true;

        var formData = new FormData();
        formData.append('action', 'edd_mp_remove_cart_item');
        formData.append('nonce', eddMpCheckout.nonce);
        formData.append('cart_key', cartKey);

        fetch(eddMpCheckout.ajaxUrl, {
          method: 'POST',
          body: formData,
          credentials: 'same-origin'
        })
          .then(function (response) {
            return response.json();
          })
          .then(function (data) {
            if (!data || !data.success || !data.data) {
              button.disabled = false;
              return;
            }

            var container = document.querySelector('[data-edd-mp-checkout-items]');
            if (container) {
              container.innerHTML = data.data.itemsHtml;
              bindCheckoutRemoveButtons();
            }
          })
          .catch(function () {
            button.disabled = false;
          });
      });
    });
  }

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('.edd-mp-cart-toggle');

    if (toggle) {
      var cart = toggle.closest('[data-edd-mp-cart]');
      if (!cart) {
        return;
      }

      var popup = cart.querySelector('.edd-mp-cart-popup');
      if (!popup) {
        return;
      }

      if (popup.hidden) {
        openCart(cart);
      } else {
        closeCart(cart);
      }

      return;
    }

    var closeButton = event.target.closest('.edd-mp-cart-popup-close');
    if (closeButton) {
      closeCart(closeButton.closest('[data-edd-mp-cart]'));
      return;
    }

    if (!event.target.closest('.edd-mp-cart-popup-content')) {
      closeAll();
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      closeAll();
    }
  });

  window.addEventListener('resize', function () {
    document.querySelectorAll('[data-edd-mp-cart]').forEach(function (cart) {
      var popup = cart.querySelector('.edd-mp-cart-popup');
      if (popup && !popup.hidden) {
        positionPopup(cart);
      }
    });
  });

  bindCheckoutRemoveButtons();
})();
