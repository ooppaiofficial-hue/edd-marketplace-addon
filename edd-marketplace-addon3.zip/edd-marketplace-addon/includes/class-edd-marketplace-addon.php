<?php
/**
 * Core plugin class.
 *
 * @package EDD_Marketplace_Addon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EDD_Marketplace_Addon {

	/**
	 * Singleton instance.
	 *
	 * @var EDD_Marketplace_Addon|null
	 */
	private static $instance = null;

	/**
	 * Shortcodes service.
	 *
	 * @var EDD_MP_Shortcodes
	 */
	private $shortcodes;

	/**
	 * Get singleton instance.
	 *
	 * @return EDD_Marketplace_Addon
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Activation callback.
	 *
	 * @return void
	 */
	public static function activate() {
		$instance = self::instance();
		$instance->shortcodes->ensure_checkout_page_exists();
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->shortcodes = new EDD_MP_Shortcodes();

		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'plugins_loaded', array( $this, 'bootstrap' ), 20 );
	}

	/**
	 * Load plugin textdomain.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'edd-marketplace-addon', false, dirname( plugin_basename( EDD_MP_ADDON_FILE ) ) . '/languages' );
	}

	/**
	 * Register plugin hooks.
	 *
	 * @return void
	 */
	public function bootstrap() {
		if ( ! class_exists( 'Easy_Digital_Downloads' ) && ! defined( 'EDD_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'render_missing_edd_notice' ) );
			return;
		}

		$this->shortcodes->ensure_checkout_page_exists();

		( new EDD_MP_Currency() )->hooks();
		( new EDD_MP_Commission() )->hooks();
		$this->shortcodes->hooks();
	}

	/**
	 * Render notice when EDD is not active.
	 *
	 * @return void
	 */
	public function render_missing_edd_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-error"><p>';
		echo esc_html__( 'EDD Marketplace Addon requires Easy Digital Downloads to be installed and active.', 'edd-marketplace-addon' );
		echo '</p></div>';
	}
}
