<?php
/**
 * Commission management.
 *
 * @package EDD_Marketplace_Addon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EDD_MP_Commission {
	const META_COMMISSION_PERCENT  = '_edd_mp_commission_percent';
	const PAYMENT_META_COMMISSIONS = '_edd_mp_commissions';
	const NONCE_ACTION_DOWNLOAD    = 'edd_mp_save_download_commission';
	const NONCE_NAME_DOWNLOAD      = 'edd_mp_download_commission_nonce';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter( 'edd_settings_extensions', array( $this, 'register_edd_extensions_settings' ) );
		add_action( 'add_meta_boxes', array( $this, 'register_download_meta_box' ) );
		add_action( 'save_post_download', array( $this, 'save_download_commission_meta' ) );
		add_action( 'edd_complete_purchase', array( $this, 'store_payment_commissions' ), 20, 1 );
	}

	/**
	 * Add commission settings to EDD extensions tab.
	 *
	 * @param array<int,mixed> $settings Settings.
	 * @return array<int,mixed>
	 */
	public function register_edd_extensions_settings( $settings ) {
		$settings[] = array(
			'id'   => 'edd_mp_commission_header',
			'name' => '<strong>' . esc_html__( 'Marketplace Commission', 'edd-marketplace-addon' ) . '</strong>',
			'type' => 'header',
		);

		$settings[] = array(
			'id'   => 'edd_mp_global_commission_percent',
			'name' => esc_html__( 'Global commission (%)', 'edd-marketplace-addon' ),
			'desc' => esc_html__( 'Default commission percentage used when product-specific commission is empty. Range: 0 to 100.', 'edd-marketplace-addon' ),
			'type' => 'number',
			'size' => 'small',
			'std'  => $this->get_default_global_commission(),
			'min'  => '0',
			'max'  => '100',
			'step' => '0.01',
		);

		return $settings;
	}

	/**
	 * Register commission metabox on downloads.
	 *
	 * @return void
	 */
	public function register_download_meta_box() {
		add_meta_box(
			'edd-mp-download-commission',
			esc_html__( 'Marketplace Commission', 'edd-marketplace-addon' ),
			array( $this, 'render_download_meta_box' ),
			'download',
			'side',
			'default'
		);
	}

	/**
	 * Render commission metabox.
	 *
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	public function render_download_meta_box( $post ) {
		$value = get_post_meta( $post->ID, self::META_COMMISSION_PERCENT, true );
		wp_nonce_field( self::NONCE_ACTION_DOWNLOAD, self::NONCE_NAME_DOWNLOAD );
		?>
		<p>
			<label for="edd-mp-commission-percent"><?php echo esc_html__( 'Commission percent (%)', 'edd-marketplace-addon' ); ?></label>
			<input
				id="edd-mp-commission-percent"
				name="edd_mp_commission_percent"
				type="number"
				step="0.01"
				min="0"
				max="100"
				value="<?php echo esc_attr( '' !== $value ? (string) $value : '' ); ?>"
				style="width: 100%;"
			/>
		</p>
		<p class="description"><?php echo esc_html__( 'Leave empty to use the global commission from EDD settings.', 'edd-marketplace-addon' ); ?></p>
		<?php
	}

	/**
	 * Save commission metabox.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function save_download_commission_meta( $post_id ) {
		if ( ! isset( $_POST[ self::NONCE_NAME_DOWNLOAD ] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME_DOWNLOAD ] ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION_DOWNLOAD ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['edd_mp_commission_percent'] ) ) {
			delete_post_meta( $post_id, self::META_COMMISSION_PERCENT );
			return;
		}

		$raw_value = trim( (string) wp_unslash( $_POST['edd_mp_commission_percent'] ) );
		if ( '' === $raw_value ) {
			delete_post_meta( $post_id, self::META_COMMISSION_PERCENT );
			return;
		}

		$normalized = $this->normalize_percentage( (float) $raw_value );
		update_post_meta( $post_id, self::META_COMMISSION_PERCENT, $normalized );
	}

	/**
	 * Store commission data at purchase completion.
	 *
	 * @param int $payment_id Payment ID.
	 * @return void
	 */
	public function store_payment_commissions( $payment_id ) {
		$payment_id = absint( $payment_id );
		if ( $payment_id <= 0 ) {
			return;
		}

		$existing = get_post_meta( $payment_id, self::PAYMENT_META_COMMISSIONS, true );
		if ( is_array( $existing ) && ! empty( $existing ) ) {
			return;
		}

		$cart_items = edd_get_payment_meta_cart_details( $payment_id, true );
		if ( empty( $cart_items ) || ! is_array( $cart_items ) ) {
			return;
		}

		$commissions = array();
		foreach ( $cart_items as $index => $item ) {
			$download_id = isset( $item['id'] ) ? absint( $item['id'] ) : 0;
			if ( $download_id <= 0 ) {
				continue;
			}

			$line_total = isset( $item['price'] ) ? (float) $item['price'] : 0.0;
			if ( $line_total < 0 ) {
				$line_total = 0.0;
			}

			$commission_percent = $this->get_download_commission_percentage( $download_id );
			$commission_amount  = round( ( $line_total * $commission_percent ) / 100, edd_currency_decimal_filter() );
			$vendor_amount      = max( 0, $line_total - $commission_amount );
			$vendor_id          = (int) get_post_field( 'post_author', $download_id );

			$commissions[] = array(
				'index'              => absint( $index ),
				'download_id'        => $download_id,
				'line_total'         => $line_total,
				'commission_percent' => $commission_percent,
				'commission_amount'  => $commission_amount,
				'vendor_amount'      => $vendor_amount,
				'vendor_user_id'     => $vendor_id,
			);
		}

		if ( ! empty( $commissions ) ) {
			update_post_meta( $payment_id, self::PAYMENT_META_COMMISSIONS, $commissions );
		}
	}

	/**
	 * Get commission percentage for download.
	 *
	 * @param int $download_id Download ID.
	 * @return float
	 */
	private function get_download_commission_percentage( $download_id ) {
		$download_value = get_post_meta( $download_id, self::META_COMMISSION_PERCENT, true );
		if ( '' !== (string) $download_value ) {
			return $this->normalize_percentage( (float) $download_value );
		}

		return $this->get_global_commission_percentage();
	}

	/**
	 * Get global commission.
	 *
	 * @return float
	 */
	private function get_global_commission_percentage() {
		$value = edd_get_option( 'edd_mp_global_commission_percent', $this->get_default_global_commission() );
		return $this->normalize_percentage( (float) $value );
	}

	/**
	 * Default global commission.
	 *
	 * @return float
	 */
	private function get_default_global_commission() {
		return 10.0;
	}

	/**
	 * Normalize percentage value.
	 *
	 * @param float $value Value.
	 * @return float
	 */
	private function normalize_percentage( $value ) {
		$value = max( 0.0, min( 100.0, $value ) );
		return round( $value, 2 );
	}
}
