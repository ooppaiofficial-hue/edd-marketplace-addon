<?php
/**
 * Currency integration.
 *
 * @package EDD_Marketplace_Addon
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EDD_MP_Currency {

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter( 'edd_currencies', array( $this, 'register_iran_toman_currency' ) );
		add_filter( 'edd_currency_symbol', array( $this, 'register_iran_toman_symbol' ), 10, 2 );
		add_filter( 'edd_get_payment_currency', array( $this, 'force_payment_currency' ) );
		add_filter( 'edd_currency_decimal_count', array( $this, 'adjust_decimal_count_for_irt' ), 20, 2 );
		add_filter( 'edd_settings_general', array( $this, 'register_edd_general_settings' ) );
	}

	/**
	 * Add Iran Toman currency.
	 *
	 * @param array<string,string> $currencies Currency list.
	 * @return array<string,string>
	 */
	public function register_iran_toman_currency( $currencies ) {
		$currencies['IRT'] = __( 'Iran Toman (IRT)', 'edd-marketplace-addon' );
		return $currencies;
	}

	/**
	 * Set symbol for Iran Toman.
	 *
	 * @param string $symbol Symbol.
	 * @param string $currency Currency code.
	 * @return string
	 */
	public function register_iran_toman_symbol( $symbol, $currency ) {
		if ( 'IRT' === strtoupper( (string) $currency ) ) {
			return 'تومان';
		}

		return $symbol;
	}

	/**
	 * Add currency settings to EDD general tab.
	 *
	 * @param array<int,mixed> $settings Settings.
	 * @return array<int,mixed>
	 */
	public function register_edd_general_settings( $settings ) {
		$settings[] = array(
			'id'   => 'edd_mp_currency_header',
			'name' => '<strong>' . esc_html__( 'Marketplace Addon', 'edd-marketplace-addon' ) . '</strong>',
			'type' => 'header',
		);

		$settings[] = array(
			'id'   => 'edd_mp_force_irt_currency',
			'name' => esc_html__( 'Force IRT currency', 'edd-marketplace-addon' ),
			'desc' => esc_html__( 'Force all purchases to use IRT (Iran Toman).', 'edd-marketplace-addon' ),
			'type' => 'checkbox',
		);

		return $settings;
	}

	/**
	 * Force payment currency.
	 *
	 * @param string $currency Current currency.
	 * @return string
	 */
	public function force_payment_currency( $currency ) {
		$force = edd_get_option( 'edd_mp_force_irt_currency', false );
		if ( $force ) {
			return 'IRT';
		}

		return $currency;
	}

	/**
	 * Force decimal count to 0 for IRT.
	 *
	 * @param int    $decimals Decimal count.
	 * @param string $currency Currency code.
	 * @return int
	 */
	public function adjust_decimal_count_for_irt( $decimals, $currency ) {
		if ( 'IRT' === strtoupper( (string) $currency ) || $this->is_irt_currency_active() ) {
			return 0;
		}

		return (int) $decimals;
	}

	/**
	 * Determine whether IRT is active.
	 *
	 * @return bool
	 */
	private function is_irt_currency_active() {
		$forced = edd_get_option( 'edd_mp_force_irt_currency', false );
		if ( $forced ) {
			return true;
		}

		$currency = edd_get_currency();
		return 'IRT' === strtoupper( (string) $currency );
	}
}
