(function () {
  'use strict';

  function closeAll(except) {
    document.querySelectorAll('[data-edd-mp-cart]').forEach(function (cart) {
      if (except && cart === except) {
        return;
      }

      var panel = cart.querySelector('.edd-mp-cart-content');
      var toggle = cart.querySelector('.edd-mp-cart-toggle');
      if (panel && toggle) {
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function bindCheckoutRemoveButtons() {
    document.querySelectorAll('.edd-mp-remove-item').forEach(function (button) {
      if (button.dataset.bound === '1') {
        return;
      }

      button.dataset.bound = '1';
      button.addEventListener('click', function () {
        var cartKey = button.getAttribute('data-cart-key');
        if (!cartKey || typeof eddMpCheckout === 'undefined') {
          return;
        }

        button.disabled = true;

        var formData = new FormData();
        formData.append('action', 'edd_mp_remove_cart_item');
        formData.append('nonce', eddMpCheckout.nonce);
        formData.append('cart_key', cartKey);

        fetch(eddMpCheckout.ajaxUrl, {
          method: 'POST',
          body: formData,
          credentials: 'same-origin'
        })
          .then(function (response) {
            return response.json();
          })
          .then(function (data) {
            if (!data || !data.success || !data.data) {
              button.disabled = false;
              return;
            }

            var container = document.querySelector('[data-edd-mp-checkout-items]');
            if (container) {
              container.innerHTML = data.data.itemsHtml;
              bindCheckoutRemoveButtons();
            }
          })
          .catch(function () {
            button.disabled = false;
          });
      });
    });
  }

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest('.edd-mp-cart-toggle');

    if (toggle) {
      var cart = toggle.closest('[data-edd-mp-cart]');
      if (!cart) {
        return;
      }

      var panel = cart.querySelector('.edd-mp-cart-content');
      if (!panel) {
        return;
      }

      var willOpen = panel.hidden;
      closeAll(cart);
      panel.hidden = !willOpen;
      toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
      return;
    }

    if (!event.target.closest('[data-edd-mp-cart]')) {
      closeAll(null);
    }
  });

  bindCheckoutRemoveButtons();
})();
